import base64
import gzip

def decode(data):
    # Step 1: URL-safe Base64 decode
    decoded = base64.urlsafe_b64decode(data)

    # Step 2: Gzip decompress
    decompressed = gzip.decompress(decoded)

    # Step 3: Convert to string
    result = decompressed.decode("utf-8", errors="ignore")

    return result

def encode(data):
    raw_bytes = data.encode("utf-8")

    # 2. Gzip compress
    compressed = gzip.compress(raw_bytes)

    # 3. Base64 encode
    b64 = base64.b64encode(compressed).decode("utf-8")

    # 4. Make URL-safe (GD style)
    result = b64.replace("+", "-").replace("/", "_")

    return result

inp = input("Encode or decode? (e/d): ").strip().lower()
if inp == "e":
    text = input("Enter text to encode: ")
    encoded = encode(text)
    print("Encoded:", encoded)
elif inp == "d":
    text = input("Enter text to decode: ")
    decoded = decode(text)
    print("Decoded:", decoded)

input("Press any key to exit...")