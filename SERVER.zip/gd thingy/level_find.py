import requests
import base64
import zlib
import time
import os
import re

def fix_padding(s):
    # Add '=' padding if missing
    return s + "=" * (-len(s) % 4)

def try_decompress(encoded_data):
    decoded_data = base64.urlsafe_b64decode(fix_padding(encoded_data))

    for wbits, name in [(16 + zlib.MAX_WBITS, "gzip"), (0, "zlib"), (-zlib.MAX_WBITS, "raw deflate")]:
        try:
            decompressed = zlib.decompress(decoded_data, wbits=wbits)
            print(f"Decompression succeeded with {name} mode.")
            return decompressed.decode('utf-8', errors='ignore')
        except Exception as e:
            print(f"Decompression failed with {name} mode: {e}")
    return None

def sanitize_filename(name):
    # Remove characters illegal in Windows/macOS/Linux filenames
    name = re.sub(r'[\\/:*?"<>|]', '_', name)
    name = name.strip()
    if not name:
        name = "unnamed_level"
    return name

def download_level(level_id):
    url = "http://www.boomlings.com/database/downloadGJLevel22.php"
    payload = {
        "gameVersion": "22",
        "binaryVersion": "35",
        "gdw": "0",
        "levelID": str(level_id),
        "secret": "Wmfd2893gb7"
    }
    headers = {
        "User-Agent": ""  # must be empty to bypass Cloudflare
    }

    response = requests.post(url, data=payload, headers=headers)
    text = response.text.strip()

    print(f"Raw response (first 300 chars):\n{text[:300]}")

    if text == "-1":
        raise ValueError(f"Level {level_id} not found (server returned -1).")

    # Parse the colon-delimited response to find the '4:' key for level data
    parts = text.split(":")
    if "4" not in parts:
        raise ValueError("Invalid response format: missing '4:' key for level data")

    idx = parts.index("4")
    encoded_data = parts[idx + 1]

    decompressed_str = try_decompress(encoded_data)
    if decompressed_str is None:
        raise ValueError("All decompression attempts failed — invalid or corrupted compressed data.")

    # Extract some metadata
    metadata_keys = {"1": "levelID", "2": "name", "3": "creator", "9": "likes", "10": "downloads"}
    metadata = {}
    for key, name in metadata_keys.items():
        if key in parts:
            metadata[name] = parts[parts.index(key) + 1]

    return decompressed_str, metadata

if __name__ == "__main__":
    lvl = input("Enter Geometry Dash level ID: ").strip()
    try:
        level_string, meta = download_level(lvl)

        level_name = meta.get("name", f"level_{lvl}")
        safe_name = sanitize_filename(level_name)
        filename = safe_name + ".gmd"

        script_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(script_dir, filename)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(level_string)

        print(f"\nLevel {lvl} downloaded successfully!")
        print("Metadata:")
        for k, v in meta.items():
            print(f"  {k}: {v}")

        print(f"\nSaved as: {file_path}")
        print("\n--- Level string preview ---")
        print(level_string[:1000])  # preview first part only

        input("\nPress Enter to exit...")

    except Exception as e:
        print(f"Error: {e}")
        input("Press Enter to exit...")
