from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
import requests
import base64
import zlib
import asyncio

from hypercorn.asyncio import serve
from hypercorn.config import Config

app = FastAPI()

SECRET = "Wmfd2893gb7"

def fix_padding(s: str) -> str:
    return s + "=" * (-len(s) % 4)

def try_decompress(encoded_data: str) -> str | None:
    decoded_data = base64.urlsafe_b64decode(fix_padding(encoded_data))
    for wbits in (16 + zlib.MAX_WBITS, 0, -zlib.MAX_WBITS):
        try:
            decompressed = zlib.decompress(decoded_data, wbits=wbits)
            return decompressed.decode("utf-8", errors="ignore")
        except Exception:
            pass
    return None

def download_level(level_id: str) -> tuple[str, dict]:
    print("downloading")
    url = "http://www.boomlings.com/database/downloadGJLevel22.php"
    payload = {
        "gameVersion": "22",
        "binaryVersion": "35",
        "gdw": "0",
        "levelID": level_id,
        "secret": SECRET
    }
    headers = {"User-Agent": ""}

    response = requests.post(url, data=payload, headers=headers)
    text = response.text.strip()
    if text == "-1":
        raise ValueError(f"Level {level_id} not found (server returned -1).")

    parts = text.split(":")
    if "4" not in parts:
        raise ValueError("Invalid response format: missing '4:' key for level data")

    idx = parts.index("4")
    encoded_data = parts[idx + 1]
    decompressed_str = try_decompress(encoded_data)
    if decompressed_str is None:
        raise ValueError("All decompression attempts failed — invalid or corrupted data.")

    metadata_keys = {"1": "levelID", "2": "name", "3": "creator", "9": "likes", "10": "downloads"}
    metadata = {}
    for key, name in metadata_keys.items():
        if key in parts:
            metadata[name] = parts[parts.index(key) + 1]
    if level_id != "128":
        print("downloaded level:", level_id)
    return decompressed_str, metadata

class LevelRequest(BaseModel):
    level_id: str

@app.post("/download_level")
def api_download_level(req: LevelRequest):
    try:
        level_string, metadata = download_level(req.level_id)
        return {"success": True, "metadata": metadata, "level_string": level_string}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/obtainlevels/{full_path:path}")
def obtain_levels(full_path: str, request: Request):
    query_string = str(request.query_params)
    target_url = f"http://gdbrowser.com/api/search/{full_path}"
    if query_string:
        target_url += f"?{query_string}"

    try:

        resp = requests.get(target_url, timeout=10)

        if resp.status_code != 200:
            raise HTTPException(status_code=resp.status_code, detail=resp.text)

        print("searching:", full_path + "?" + query_string)
        return resp.json()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    config = Config()
    config.bind = ["0.0.0.0:8080"]
    print("Server running on http://127.0.0.1:8080")
    asyncio.run(serve(app, config))
