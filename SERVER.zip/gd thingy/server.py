from pydantic import BaseModel
import requests
import base64
import zlib
import asyncio
import httpx
from fastapi import FastAPI, HTTPException, Request
from urllib.parse import unquote

from hypercorn.asyncio import serve
from hypercorn.config import Config

app = FastAPI()

import requests
import re
import html

ngsession = requests.Session()

SONG_CACHE = {}

@app.get("/ng_audio/{audio_id}")
def get_newgrounds_audio_info(audio_id):
    req = requests.post(
        "https://www.boomlings.com/database/getGJSongInfo.php",
        data={
            "secret": "Wmfd2893gb7",
            "songID": audio_id
        },
        headers={
            "User-Agent": ""
        }
    )

    text = req.text

    # Split GD response
    parts = text.split("~|~")

    # Convert into key/value table
    table = {}

    for i in range(0, len(parts) - 1, 2):
        table[parts[i]] = parts[i + 1]

    # Correct mappings
    song_id = table.get("1")
    title = table.get("2")
    author_id = table.get("3")
    author = table.get("4")
    filesize = table.get("5")
    audio_url = table.get("10")

    # Decode strings
    if title:
        title = unquote(html.unescape(title))

    if author:
        author = unquote(html.unescape(author))

    if audio_url:
        audio_url = unquote(audio_url).replace("\\/", "/")

    print(f"obtained {title or 'Unknown'}")

    return {
        "song_id": song_id or "Unknown",
        "title": title or "Unknown",
        "author_id": author_id or "Unknown",
        "author": author or "Unknown",
        "size_mb": filesize or "Unknown",
        "url": audio_url or "Unknown",
        "raw_table": table
    }

# -----------------------------------
# EXAMPLE
# -----------------------------------

SECRET = "Wmfd2893gb7"

# ==========================================
# PORTED DATA & UTILITIES
# ==========================================

MUSIC = [
    ["Stay Inside Me", "OcularNebula"],
    ["Stereo Madness", "ForeverBound"],
    ["Back on Track", "DJVI"],
    ["Polargeist", "Step"],
    ["Dry Out", "DJVI"],
    ["Base After Base", "DJVI"],
    ["Can't Let Go", "DJVI"],
    ["Jumper", "Waterflame"],
    ["Time Machine", "Waterflame"],
    ["Cycles", "DJVI"],
    ["xStep", "DJVI"],
    ["Clutterfunk", "Waterflame"],
    ["Theory of Everything", "DJ-Nate"],
    ["Electroman Adventures", "Waterflame"],
    ["Clubstep", "DJ-Nate"],
    ["Electrodynamix", "DJ-Nate"],
    ["Hexagon Force", "Waterflame"],
    ["Blast Processing", "Waterflame"],
    ["Theory of Everything 2", "DJ-Nate"],
    ["Geometrical Dominator", "Waterflame"],
    ["Deadlocked", "F-777"],
    ["Fingerdash", "MDK"],
    ["The Seven Seas", "F-777"],
    ["Viking Arena", "F-777"],
    ["Airborne Robots", "F-777"],
    ["The Challenge", "RobTop"],
    ["Payload", "Dex Arson"],
    ["Beast Mode", "Dex Arson"],
    ["Machina", "Dex Arson"],
    ["Years", "Dex Arson"],
    ["Frontlines", "Dex Arson"],
    ["Space Pirates", "Waterflame"],
    ["Striker", "Waterflame"],
    ["Embers", "Dex Arson"],
    ["Round 1", "Dex Arson"],
    ["Monster Dance Off", "F-777"],
    ["Press Start", "MDK"],
    ["Nock Em", "Bossfight"],
    ["Power Trip", "Boom Kitty"]
]

class XOR:
    def xor(self, string_data: str, key: int) -> str:
        key_str = str(key)
        res = []
        for i, char in enumerate(string_data):
            res.append(chr(ord(char) ^ ord(key_str[i % len(key_str)])))
        return "".join(res)

    def encrypt(self, string_data: str, key: int = 37526) -> str:
        xored = self.xor(string_data, key)
        return base64.urlsafe_b64encode(xored.encode('utf-8')).decode('utf-8').rstrip("=")

    def decrypt(self, string_data: str, key: int = 37526) -> str:
        padded = string_data + "=" * (-len(string_data) % 4)
        try:
            decoded = base64.urlsafe_b64decode(padded).decode('utf-8', errors='ignore')
            return self.xor(decoded, key)
        except Exception:
            return ""

def parse_gd_response(data: str, sep: str = ':') -> dict:
    parts = data.split(sep)
    return {parts[i]: parts[i+1] for i in range(0, len(parts)-1, 2)}

def safe_int(val, default=0):
    if not val:
        return default
    try:
        return int(val)
    except (ValueError, TypeError):
        return default

class Level:
    def __init__(self, level_info: dict, author_info: list = None, songs: dict = None):
        self.name = level_info.get("2", "-")
        self.id = level_info.get("1", "0")
        
        raw_desc = level_info.get("3", "")
        try:
            desc_padded = raw_desc + "=" * (-len(raw_desc) % 4)
            self.description = base64.urlsafe_b64decode(desc_padded).decode('utf-8', errors='ignore') or "(No description provided)"
        except Exception:
            self.description = "(No description provided)"

        author_info = author_info or []
        self.author = author_info[0] if len(author_info) > 0 else "-"
        self.playerID = safe_int(level_info.get("6"))
        self.accountID = safe_int(author_info[1]) if len(author_info) > 1 else 0

        diff_map = {0: 'Unrated', 10: 'Easy', 20: 'Normal', 30: 'Hard', 40: 'Harder', 50: 'Insane'}
        self.difficulty = diff_map.get(safe_int(level_info.get("9")), "Unrated")

        self.downloads = safe_int(level_info.get("10"))
        self.likes = safe_int(level_info.get("14"))
        self.disliked = safe_int(level_info.get("14")) < 0

        len_map = ['Tiny', 'Short', 'Medium', 'Long', 'XL', 'Plat']
        idx_15 = safe_int(level_info.get("15", 4))
        self.length = len_map[idx_15] if idx_15 < len(len_map) else "XL"

        self.stars = safe_int(level_info.get("18"))
        orbs_map = [0, 0, 50, 75, 125, 175, 225, 275, 350, 425, 500]
        self.orbs = orbs_map[self.stars] if self.stars < len(orbs_map) else 0
        self.diamonds = 0 if self.stars < 2 else self.stars + 2

        self.featured = safe_int(level_info.get("19")) > 0
        self.epic = safe_int(level_info.get("42")) > 0
        self.legendary = self.epic == 2
        self.mythic = self.epic == 3

        gv = safe_int(level_info.get("13"))
        self.gameVersion = f"{(gv / 10):.1f}" if gv > 17 else ("1.8" if gv == 11 else ("1.7" if gv == 10 else "Pre-1.7"))

        # Timestamps and Editor Times
        if "28" in level_info: self.uploaded = level_info["28"]
        if "29" in level_info: self.updated = level_info["29"]
        if "46" in level_info: self.editorTime = safe_int(level_info["46"])
        if "47" in level_info: self.totalEditorTime = safe_int(level_info["47"])

        pass_raw = level_info.get("27", "")
        self.password = pass_raw
        if self.password and self.password != "0":
            xor = XOR()
            dec = xor.decrypt(self.password, 26364)
            if len(dec) > 1: self.password = dec[1:]
            else: self.password = dec

        self.version = safe_int(level_info.get("5"))
        self.copiedID = level_info.get("30", "0")
        self.twoPlayer = safe_int(level_info.get("31")) > 0

        self.customSong = safe_int(level_info.get("35"))
        self.songID = safe_int(level_info.get("35"))
        self.officialSong = 0 if self.customSong > 0 else safe_int(level_info.get("12")) + 1
        print("Custom song ID:", self.customSong)
        if self.customSong > 0:
            song_id_str = str(self.customSong)

            if song_id_str in SONG_CACHE:
                ng = SONG_CACHE[song_id_str]
            else:
                ng = get_newgrounds_audio_info(song_id_str)
                SONG_CACHE[song_id_str] = ng

            self.songName = ng.get("title", "Unknown")
            self.songAuthor = ng.get("author", "Unknown")
            self.songSize = ng.get("size", "Unknown")
            self.songID = self.customSong

        if self.songID <= 0:
            idx = self.officialSong
            if idx < len(MUSIC):
                self.songName = MUSIC[idx][0]
                self.songAuthor = MUSIC[idx][1]
            else:
                self.songName = "Unknown"
                self.songAuthor = "Unknown"
            self.songSize = "0MB"
            self.songID = f"Level {self.officialSong}"

        self.coins = safe_int(level_info.get("37"))
        self.verifiedCoins = safe_int(level_info.get("38")) > 0
        self.starsRequested = safe_int(level_info.get("39"))
        self.ldm = safe_int(level_info.get("40")) > 0

        daily_val = safe_int(level_info.get("41"))
        if daily_val > 100000:
            self.weekly = True
        if daily_val > 0:
            self.dailyNumber = daily_val - 100000 if daily_val > 100000 else daily_val
            self.nextDaily = None
            self.nextDailyTimestamp = None

        self.objects = safe_int(level_info.get("45"))
        self.large = self.objects > 40000
        self.cp = int((self.stars > 0) + self.featured + self.epic)

        demon_types = {3: "Easy", 4: "Medium", 5: "Insane", 6: "Extreme"}
        if safe_int(level_info.get("17")) > 0:
            dt = safe_int(level_info.get("43", 3))
            self.difficulty = f"{demon_types.get(dt, 'Hard')} Demon"
        if safe_int(level_info.get("25")) > 0:
            self.difficulty = 'Auto'

def fix_padding(s: str) -> str:
    return s + "=" * (-len(s) % 4)

def try_decompress(encoded_data: str) -> str | None:
    decoded_data = base64.urlsafe_b64decode(fix_padding(encoded_data))
    for wbits in (16 + zlib.MAX_WBITS, 0, -zlib.MAX_WBITS):
        try:
            decompressed = zlib.decompress(decoded_data, wbits=wbits)
            return decompressed.decode("utf-8", errors="ignore")
        except Exception:
            pass
    return None

def download_level(level_id: str) -> tuple[str, dict]:
    print("downloading")
    url = "http://www.boomlings.com/database/downloadGJLevel22.php"
    payload = {
        "gameVersion": "22",
        "binaryVersion": "35",
        "gdw": "0",
        "levelID": level_id,
        "secret": SECRET
    }
    headers = {"User-Agent": ""}

    response = requests.post(url, data=payload, headers=headers)
    text = response.text.strip()
    if text == "-1":
        raise ValueError(f"Level {level_id} not found (server returned -1).")

    parts = text.split(":")
    if "4" not in parts:
        raise ValueError("Invalid response format: missing '4:' key for level data")

    idx = parts.index("4")
    encoded_data = parts[idx + 1]
    decompressed_str = try_decompress(encoded_data)
    if decompressed_str is None:
        raise ValueError("All decompression attempts failed — invalid or corrupted data.")

    metadata_keys = {"1": "levelID", "2": "name", "3": "creator", "9": "likes", "10": "downloads"}
    metadata = {}
    for key, name in metadata_keys.items():
        if key in parts:
            metadata[name] = parts[parts.index(key) + 1]
    print("downloaded level:", level_id)
    return decompressed_str, metadata

class LevelRequest(BaseModel):
    level_id: str

@app.post("/download_level")
def api_download_level(req: LevelRequest):
    try:
        level_string, metadata = download_level(req.level_id)
        return {"success": True, "metadata": metadata, "level_string": level_string}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/obtainlevels/{full_path:path}")
async def obtain_levels(full_path: str, request: Request):
    q = request.query_params
    
    search_type = q.get("type", "0")
    type_mapping = {
        'mostdownloaded': 1, 'mostliked': 2, 'trending': 3, 'recent': 4, 'user': 5,
        'featured': 6, 'magic': 7, 'awarded': 11, 'starred': 11,
    'halloffame': 16, 'hof': 16, 'gdw': 17, 'gdworld': 17, 'daily': 21, 'weekly': 22, 'event': 23, 'sent': 24
    }

    url = "http://www.boomlings.com/database/getGJLevels21.php"

    gdps = q.get("gdps", "0")

    if gdps != "0":
        gdps = gdps.replace("http://", "").replace("https://", "")

        url = f"http://{gdps.rstrip('/')}/getGJLevels21.php"

    if not str(search_type).isdigit():
        search_type = type_mapping.get(str(search_type).lower(), 0)

    payload = {
        "secret": SECRET,
        "type": search_type,
        "str": full_path,
        "diff": q.get("diff", "-"),
        "page": q.get("page", "0"),
        "len": q.get("length", "-"),
        "song": q.get("songID", ""),
        "demonFilter": q.get("demonFilter", ""),
        "featured": 1 if "featured" in q else 0,
        "original": 1 if "original" in q else 0,
        "twoPlayer": 1 if "twoPlayer" in q else 0,
        "coins": 1 if "coins" in q else 0,
        "epic": 1 if "epic" in q else 0,
        "mythic": 1 if "legendary" in q else 0,
        "legendary": 1 if "mythic" in q else 0,
        "star": 1 if "starred" in q else 0,
        "noStar": 1 if "noStar" in q else 0,
        "customSong": 1 if "customSong" in q else 0,
    }
    
    headers = {
        "User-Agent": "",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(url, data=payload, headers=headers)
            body = resp.text.strip()
            
            print(f"searching: {full_path}?{q}")

            if not body or body == "-1":
                return []

            split_body = body.split('#')
            levels_str = split_body[0] if len(split_body) > 0 else ""
            authors_str = split_body[1] if len(split_body) > 1 else ""
            songs_str = split_body[2] if len(split_body) > 2 else ""
            
            authors_dict = {}
            for x in authors_str.split('|'):
                if not x or x.startswith('~'): continue
                arr = x.split(':')
                if len(arr) >= 3:
                    authors_dict[arr[0]] = [arr[1], arr[2]]
            
            songs_dict = {}
            for s in songs_str.split('~:~'):
                if not s: continue
                s = f"~{s}~"
                s_parsed = parse_gd_response(s, '~|~')
                if '~1~' in s_parsed:
                    songs_dict[s_parsed['~1~']] = {k.strip('~'): v for k, v in s_parsed.items()}

            parsed_levels = []
            for y, lvl in enumerate(levels_str.split('|')):
                if not lvl: continue
                lvl_info = parse_gd_response(lvl, ':')
                
                player_id = lvl_info.get('6', '0')
                author_data = authors_dict.get(player_id, ["-", "0"])
                
                level_obj = Level(lvl_info, author_info=author_data, songs=songs_dict)
                level_dict = level_obj.__dict__
                
                if y == 0 and len(split_body) > 3 and split_body[3]:
                    pages_info = split_body[3].split(":")
                    level_dict["results"] = int(pages_info[0])
                    import math
                    level_dict["pages"] = 1000 if int(pages_info[0]) == 9999 else math.ceil(int(pages_info[0]) / 10)

                parsed_levels.append(level_dict)

            print("searched")

            return parsed_levels

    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    config = Config()
    config.bind = ["0.0.0.0:8080"]
    print("Server running on http://127.0.0.1:8080")
    asyncio.run(serve(app, config))