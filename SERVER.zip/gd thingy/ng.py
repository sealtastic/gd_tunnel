import requests

req = requests.post("https://www.boomlings.com/database/getGJSongInfo.php", data={"secret": "Wmfd2893gb7","songID": input("Enter song ID: ")}, headers={"User-Agent": ""})
print(req.text)